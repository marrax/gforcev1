# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
Gforcev1::Application.config.secret_key_base = '63fff4bb3208270ee4861934c706e6815e95979111e7492d7543443dbd15413ad6c4ba5561d9ea0ad9c421860e2c2291ca18c96652ec208e43f8d6c32d84021a'
